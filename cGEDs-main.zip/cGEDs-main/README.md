
# RShiny2022 App: cGEDs (Cancer Gene-expression Drug-Sensitivity) App
This repository is dedicated to the documentation and management of cGEDs (Cancer Gene-expression Drug-Sensitivity) RShiny app (2022).

---
#### Web Links
- Webserver:
- Documentation:
- STEM-Away: [https://stemaway.com/](https://stemaway.com/)

---
#### Developement Details:

- R version used: 4.1.3
- Current Deployment:  `

---
#### Steps to run at localhost
